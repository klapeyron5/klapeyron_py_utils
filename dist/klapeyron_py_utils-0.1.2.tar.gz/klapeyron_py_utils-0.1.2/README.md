# klapeyron_py_utils

Just a lot of my common reusable code for python

# installation:
pip install git+https://github.com/klapeyron5/klapeyron_py_utils

# usage:
import klapeyron_py_utils
