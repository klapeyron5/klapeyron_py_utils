import matplotlib.pyplot as plt


def plot_1D_signal(signal):

    pass